#define _GNU_SOURCE
#include <sys/mman.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

static uint32_t *dumb_bufs[4] = {NULL};
static int num_bufs = 0;

void *mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset) {
    static void *(*real_mmap)(void *, size_t, int, int, int, off_t) = NULL;
    if (!real_mmap) {
        real_mmap = dlsym(RTLD_NEXT, "mmap");
    }
    if (prot & PROT_WRITE) {
        prot |= PROT_READ;
    }
    void *res = real_mmap(addr, length, prot, flags, fd, offset);
    if (res != MAP_FAILED && length >= 1200*2670*4 && num_bufs < 4) {
        dumb_bufs[num_bufs++] = (uint32_t *)res;
        FILE *f = fopen("/tmp/mmap_diag.log", "a");
        if (f) {
            fprintf(f, "Mapped dumb_buf[%d] at %p len=%zu prot=0x%x fd=%d off=0x%lx\n", num_bufs-1, res, length, prot, fd, (unsigned long)offset);
            fclose(f);
        }
    }
    return res;
}

int drmModeAtomicCommit(int fd, void *req, uint32_t flags, void *user_data) {
    static int (*real_commit)(int, void *, uint32_t, void *) = NULL;
    static int commit_cnt = 0;
    if (!real_commit) {
        real_commit = dlsym(RTLD_NEXT, "drmModeAtomicCommit");
    }
    int rc = real_commit(fd, req, flags, user_data);
    if ((flags & 0x0100) == 0 && commit_cnt < 10) { /* not TEST_ONLY */
        FILE *f = fopen("/tmp/mmap_diag.log", "a");
        if (f) {
            fprintf(f, "AtomicCommit #%d flags=0x%x rc=%d: ", commit_cnt, flags, rc);
            for (int b = 0; b < num_bufs; b++) {
                uint32_t *p = dumb_bufs[b];
                int nonzero = 0;
                uint32_t sample = p[1200*100 + 600];
                for (int i = 0; i < 1200*2670; i += 1000) {
                    if ((p[i] & 0x00ffffff) != 0) nonzero++;
                }
                fprintf(f, "buf[%d] sample=0x%08x nonzero=%d/3204 ", b, sample, nonzero);
            }
            fprintf(f, "\n");
            fclose(f);
        }
        commit_cnt++;
    }
    return rc;
}
